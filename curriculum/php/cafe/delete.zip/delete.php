<html>
  <body>

    <?php
        // データベースの接続情報
        $dsn ='mysql:host=mysql;dbname=cafe;charset=utf8mb4';
        $username = 'root';
        $password = 'root';

        try {
      
          // PDOインスタンスを作成
          $pdo = new PDO($dsn, $username, $password);
          
          // エラーモードを設定（例外を投げるようにする）
          $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
          
          // SQLクエリを作成
          $sql = 'SELECT * FROM contacts'; 
          // 'users'テーブルの全データを取得
          
          // クエリを実行
          $stmt = $pdo->query($sql);

          $row = $stmt->fetch(PDO::FETCH_ASSOC);

           

            
        } catch (PDOException $e) {
          // エラーメッセージを表示
          echo 'Connection failed: ' . $e->getMessage();
        }
    ?>
  </body>
</html>